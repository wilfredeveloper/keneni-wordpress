<?php
/**
 * CBC School Modern Theme Functions
 */

// Theme setup
function cbc_school_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-logo');
    add_theme_support('customize-selective-refresh-widgets');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'cbc-school-modern'),
        'footer' => __('Footer Menu', 'cbc-school-modern'),
    ));
    
    // Add image sizes
    add_image_size('hero-image', 800, 600, true);
    add_image_size('featured-image', 400, 300, true);
}
add_action('after_setup_theme', 'cbc_school_setup');

// Enqueue styles and scripts
function cbc_school_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style('cbc-school-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    
    // Enqueue main JavaScript
    wp_enqueue_script('cbc-school-script', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0.0', true);
    
    // Enqueue comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'cbc_school_scripts');

// Register widget areas
function cbc_school_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'cbc-school-modern'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'cbc-school-modern'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer 1', 'cbc-school-modern'),
        'id'            => 'footer-1',
        'description'   => __('Footer widget area 1.', 'cbc-school-modern'),
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer 2', 'cbc-school-modern'),
        'id'            => 'footer-2',
        'description'   => __('Footer widget area 2.', 'cbc-school-modern'),
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer 3', 'cbc-school-modern'),
        'id'            => 'footer-3',
        'description'   => __('Footer widget area 3.', 'cbc-school-modern'),
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'cbc_school_widgets_init');

// Custom post types for school content
function cbc_school_custom_post_types() {
    // Events post type
    register_post_type('events', array(
        'labels' => array(
            'name' => __('Events', 'cbc-school-modern'),
            'singular_name' => __('Event', 'cbc-school-modern'),
            'add_new' => __('Add New Event', 'cbc-school-modern'),
            'add_new_item' => __('Add New Event', 'cbc-school-modern'),
            'edit_item' => __('Edit Event', 'cbc-school-modern'),
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-calendar-alt',
        'rewrite' => array('slug' => 'events'),
    ));
    
    // Staff post type
    register_post_type('staff', array(
        'labels' => array(
            'name' => __('Staff', 'cbc-school-modern'),
            'singular_name' => __('Staff Member', 'cbc-school-modern'),
            'add_new' => __('Add New Staff Member', 'cbc-school-modern'),
            'add_new_item' => __('Add New Staff Member', 'cbc-school-modern'),
            'edit_item' => __('Edit Staff Member', 'cbc-school-modern'),
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-groups',
        'rewrite' => array('slug' => 'staff'),
    ));
}
add_action('init', 'cbc_school_custom_post_types');

// Customizer settings
function cbc_school_customize_register($wp_customize) {
    // Hero Section
    $wp_customize->add_section('hero_section', array(
        'title' => __('Hero Section', 'cbc-school-modern'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Excellence in Education',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'cbc-school-modern'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_subtitle', array(
        'default' => 'Empowering Students Through CBC',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label' => __('Hero Subtitle', 'cbc-school-modern'),
        'section' => 'hero_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'Nurturing competent, confident, and creative learners for the 21st century.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'cbc-school-modern'),
        'section' => 'hero_section',
        'type' => 'textarea',
    ));
    
    $wp_customize->add_setting('hero_image', array(
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'hero_image', array(
        'label' => __('Hero Image', 'cbc-school-modern'),
        'section' => 'hero_section',
        'mime_type' => 'image',
    )));
    
    // School Info
    $wp_customize->add_section('school_info', array(
        'title' => __('School Information', 'cbc-school-modern'),
        'priority' => 31,
    ));
    
    $wp_customize->add_setting('school_location', array(
        'default' => 'Nairobi, Kenya',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('school_location', array(
        'label' => __('School Location', 'cbc-school-modern'),
        'section' => 'school_info',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('school_status', array(
        'default' => 'Admissions Open',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('school_status', array(
        'label' => __('School Status', 'cbc-school-modern'),
        'section' => 'school_info',
        'type' => 'text',
    ));
}
add_action('customize_register', 'cbc_school_customize_register');

// Add custom body classes
function cbc_school_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    return $classes;
}
add_filter('body_class', 'cbc_school_body_classes');
