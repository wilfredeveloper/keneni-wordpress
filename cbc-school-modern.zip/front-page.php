<?php
/**
 * The front page template file
 */

get_header();
?>

<main id="primary" class="site-main">
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-container">
            <div class="hero-content">
                <p class="hero-subtitle">
                    <?php echo esc_html(get_theme_mod('hero_subtitle', 'Empowering Students Through CBC')); ?>
                </p>
                
                <h1 class="hero-title">
                    <?php echo esc_html(get_theme_mod('hero_title', 'Excellence in Education')); ?>
                </h1>
                
                <p class="hero-description">
                    <?php echo esc_html(get_theme_mod('hero_description', 'Nurturing competent, confident, and creative learners for the 21st century through innovative teaching methods and comprehensive curriculum.')); ?>
                </p>
                
                <div class="hero-meta">
                    <span>📍 <?php echo esc_html(get_theme_mod('school_location', 'Nairobi, Kenya')); ?></span>
                    <span>✅ <?php echo esc_html(get_theme_mod('school_status', 'Admissions Open')); ?></span>
                </div>
                
                <a href="#about" class="cta-button">Learn More About Us</a>
            </div>
            
            <div class="hero-image">
                <?php
                $hero_image_id = get_theme_mod('hero_image');
                if ($hero_image_id) {
                    echo wp_get_attachment_image($hero_image_id, 'hero-image', false, array('alt' => 'School Hero Image'));
                } else {
                    // Fallback image
                    echo '<img src="' . get_template_directory_uri() . '/screenshot.png" alt="School Campus" />';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="content-section">
        <div class="container">
            <div class="text-center mb-2">
                <h2>About Our School</h2>
                <p class="lead">Committed to educational excellence and holistic development</p>
            </div>
            
            <div class="about-grid">
                <div class="about-content">
                    <h3>Our Mission</h3>
                    <p>To provide quality education that develops competent, confident, and creative learners who are prepared to excel in the 21st century global society.</p>
                    
                    <h3>Our Vision</h3>
                    <p>To be a leading educational institution that nurtures innovative thinkers, responsible citizens, and lifelong learners.</p>
                    
                    <h3>Core Values</h3>
                    <ul>
                        <li><strong>Excellence:</strong> Striving for the highest standards in all we do</li>
                        <li><strong>Integrity:</strong> Acting with honesty and moral principles</li>
                        <li><strong>Innovation:</strong> Embracing creative and forward-thinking approaches</li>
                        <li><strong>Inclusivity:</strong> Welcoming and supporting all learners</li>
                        <li><strong>Community:</strong> Building strong partnerships with families and society</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- CBC Features Section -->
    <section class="content-section" style="background-color: #f8f9fa;">
        <div class="container">
            <div class="text-center mb-2">
                <h2>Why Choose CBC Education?</h2>
                <p>The Competency-Based Curriculum focuses on developing skills, knowledge, and attitudes</p>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3>Competency-Based Learning</h3>
                    <p>Focus on developing practical skills and real-world applications rather than just theoretical knowledge.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🌟</div>
                    <h3>Holistic Development</h3>
                    <p>Nurturing intellectual, physical, social, emotional, spiritual, and moral development of every learner.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🔬</div>
                    <h3>STEM Excellence</h3>
                    <p>Strong emphasis on Science, Technology, Engineering, and Mathematics with modern laboratory facilities.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🎨</div>
                    <h3>Creative Arts</h3>
                    <p>Comprehensive arts program including music, drama, visual arts, and creative writing.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🏃</div>
                    <h3>Sports & Wellness</h3>
                    <p>Extensive sports programs and wellness initiatives to promote physical and mental health.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🌍</div>
                    <h3>Global Citizenship</h3>
                    <p>Preparing students to be responsible global citizens with cultural awareness and social responsibility.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Latest News & Events -->
    <section class="content-section">
        <div class="container">
            <div class="text-center mb-2">
                <h2>Latest News & Events</h2>
                <p>Stay updated with what's happening at our school</p>
            </div>
            
            <div class="news-grid">
                <?php
                $recent_posts = new WP_Query(array(
                    'posts_per_page' => 3,
                    'post_status' => 'publish'
                ));
                
                if ($recent_posts->have_posts()) :
                    while ($recent_posts->have_posts()) : $recent_posts->the_post();
                ?>
                    <article class="news-card">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="news-image">
                                <?php the_post_thumbnail('featured-image'); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="news-content">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p class="news-meta"><?php echo get_the_date(); ?></p>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                            <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
                        </div>
                    </article>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                    <p>No news available at the moment.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="content-section" style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); color: white;">
        <div class="container text-center">
            <h2>Ready to Join Our School Community?</h2>
            <p class="lead">Take the first step towards your child's bright future</p>
            <div class="cta-buttons">
                <a href="<?php echo esc_url(home_url('/admissions')); ?>" class="cta-button">Apply Now</a>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="cta-button" style="background: transparent; border: 2px solid white;">Schedule a Visit</a>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
?>
