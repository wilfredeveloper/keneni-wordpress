/**
 * CBC School Modern Theme JavaScript
 */

(function($) {
    'use strict';

    // Document ready
    $(document).ready(function() {
        
        // Mobile menu toggle
        initMobileMenu();
        
        // Smooth scrolling for anchor links
        initSmoothScrolling();
        
        // Header scroll effect
        initHeaderScrollEffect();
        
        // Newsletter form handling
        initNewsletterForm();
        
        // Search form enhancements
        initSearchForm();
        
        // Accessibility improvements
        initAccessibility();
        
    });

    /**
     * Initialize mobile menu functionality
     */
    function initMobileMenu() {
        // Add mobile menu toggle button if it doesn't exist
        if (!$('.mobile-menu-toggle').length) {
            $('.header-container').append('<button class="mobile-menu-toggle" aria-label="Toggle Menu"><span></span><span></span><span></span></button>');
        }
        
        // Toggle mobile menu
        $('.mobile-menu-toggle').on('click', function() {
            $(this).toggleClass('active');
            $('.main-navigation').toggleClass('mobile-active');
            $('body').toggleClass('menu-open');
        });
        
        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.main-navigation, .mobile-menu-toggle').length) {
                $('.mobile-menu-toggle').removeClass('active');
                $('.main-navigation').removeClass('mobile-active');
                $('body').removeClass('menu-open');
            }
        });
        
        // Close mobile menu on window resize
        $(window).on('resize', function() {
            if ($(window).width() > 768) {
                $('.mobile-menu-toggle').removeClass('active');
                $('.main-navigation').removeClass('mobile-active');
                $('body').removeClass('menu-open');
            }
        });
    }

    /**
     * Initialize smooth scrolling for anchor links
     */
    function initSmoothScrolling() {
        $('a[href*="#"]:not([href="#"])').on('click', function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 80
                    }, 1000);
                    return false;
                }
            }
        });
    }

    /**
     * Initialize header scroll effect
     */
    function initHeaderScrollEffect() {
        var header = $('.site-header');
        var scrollThreshold = 100;
        
        $(window).on('scroll', function() {
            var scrollTop = $(this).scrollTop();
            
            if (scrollTop > scrollThreshold) {
                header.addClass('scrolled');
            } else {
                header.removeClass('scrolled');
            }
        });
    }

    /**
     * Initialize newsletter form handling
     */
    function initNewsletterForm() {
        $('.newsletter-form').on('submit', function(e) {
            e.preventDefault();
            
            var form = $(this);
            var email = form.find('input[type="email"]').val();
            var button = form.find('button');
            var originalText = button.text();
            
            // Basic email validation
            if (!isValidEmail(email)) {
                showMessage(form, 'Please enter a valid email address.', 'error');
                return;
            }
            
            // Simulate form submission
            button.text('Subscribing...').prop('disabled', true);
            
            setTimeout(function() {
                showMessage(form, 'Thank you for subscribing to our newsletter!', 'success');
                form.find('input[type="email"]').val('');
                button.text(originalText).prop('disabled', false);
            }, 2000);
        });
    }

    /**
     * Initialize search form enhancements
     */
    function initSearchForm() {
        var searchForm = $('.search-form');
        var searchInput = searchForm.find('input[type="search"]');
        
        // Add search suggestions (placeholder functionality)
        searchInput.on('focus', function() {
            $(this).attr('placeholder', 'Search for news, events, academics...');
        });
        
        searchInput.on('blur', function() {
            $(this).attr('placeholder', 'Search...');
        });
    }

    /**
     * Initialize accessibility improvements
     */
    function initAccessibility() {
        // Add skip link
        if (!$('.skip-link').length) {
            $('body').prepend('<a class="skip-link screen-reader-text" href="#content">Skip to content</a>');
        }
        
        // Improve keyboard navigation
        $('.main-navigation a, .cta-button, .contact-btn').on('focus', function() {
            $(this).addClass('focused');
        }).on('blur', function() {
            $(this).removeClass('focused');
        });
        
        // Add ARIA labels to social links
        $('.social-links a').each(function() {
            var href = $(this).attr('href');
            if (href.includes('facebook')) {
                $(this).attr('aria-label', 'Visit our Facebook page');
            } else if (href.includes('twitter')) {
                $(this).attr('aria-label', 'Visit our Twitter page');
            } else if (href.includes('instagram')) {
                $(this).attr('aria-label', 'Visit our Instagram page');
            } else if (href.includes('linkedin')) {
                $(this).attr('aria-label', 'Visit our LinkedIn page');
            }
        });
    }

    /**
     * Utility function to validate email
     */
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Utility function to show messages
     */
    function showMessage(container, message, type) {
        var messageDiv = $('<div class="form-message ' + type + '">' + message + '</div>');
        
        // Remove existing messages
        container.find('.form-message').remove();
        
        // Add new message
        container.append(messageDiv);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            messageDiv.fadeOut(function() {
                $(this).remove();
            });
        }, 5000);
    }

    /**
     * Initialize animations on scroll (if Intersection Observer is supported)
     */
    function initScrollAnimations() {
        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate-in');
                    }
                });
            }, {
                threshold: 0.1
            });
            
            // Observe elements that should animate
            document.querySelectorAll('.feature-card, .news-card, .post-card').forEach(function(el) {
                observer.observe(el);
            });
        }
    }

    // Initialize scroll animations
    initScrollAnimations();

})(jQuery);
