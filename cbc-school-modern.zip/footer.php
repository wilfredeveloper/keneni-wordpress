    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="footer-content">
            <div class="footer-section">
                <?php if (is_active_sidebar('footer-1')) : ?>
                    <?php dynamic_sidebar('footer-1'); ?>
                <?php else : ?>
                    <h3>About Our School</h3>
                    <p>We are committed to providing excellence in education through the Competency-Based Curriculum, nurturing well-rounded students for the future.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                        <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="footer-section">
                <?php if (is_active_sidebar('footer-2')) : ?>
                    <?php dynamic_sidebar('footer-2'); ?>
                <?php else : ?>
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
                        <li><a href="<?php echo esc_url(home_url('/academics')); ?>">Academics</a></li>
                        <li><a href="<?php echo esc_url(home_url('/admissions')); ?>">Admissions</a></li>
                        <li><a href="<?php echo esc_url(home_url('/student-life')); ?>">Student Life</a></li>
                        <li><a href="<?php echo esc_url(home_url('/parents')); ?>">Parents Portal</a></li>
                        <li><a href="<?php echo esc_url(home_url('/events')); ?>">Events</a></li>
                    </ul>
                <?php endif; ?>
            </div>

            <div class="footer-section">
                <?php if (is_active_sidebar('footer-3')) : ?>
                    <?php dynamic_sidebar('footer-3'); ?>
                <?php else : ?>
                    <h3>Contact Information</h3>
                    <div class="contact-info">
                        <p><strong>Address:</strong><br>
                        123 Education Street<br>
                        Nairobi, Kenya</p>
                        
                        <p><strong>Phone:</strong><br>
                        +254 700 123 456</p>
                        
                        <p><strong>Email:</strong><br>
                        info@cbcschool.ac.ke</p>
                        
                        <p><strong>Office Hours:</strong><br>
                        Monday - Friday: 8:00 AM - 5:00 PM<br>
                        Saturday: 9:00 AM - 1:00 PM</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Stay updated with our latest news and events.</p>
                <form class="newsletter-form" action="#" method="post">
                    <input type="email" placeholder="Your email address" required>
                    <button type="submit">Subscribe</button>
                </form>
                
                <div class="accreditation">
                    <h4>Accredited By:</h4>
                    <ul>
                        <li>Ministry of Education, Kenya</li>
                        <li>Kenya National Examinations Council</li>
                        <li>International Baccalaureate Organization</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. | 
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a> | 
                <a href="<?php echo esc_url(home_url('/terms-of-service')); ?>">Terms of Service</a></p>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

<!-- Font Awesome for icons -->
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

</body>
</html>
