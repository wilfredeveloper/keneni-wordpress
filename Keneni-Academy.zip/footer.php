    </div><!-- #content -->

    <footer id="colophon" class="site-footer">
        <?php get_template_part('template-parts/footer/widgets'); ?>
        <?php get_template_part('template-parts/footer/copyright'); ?>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
