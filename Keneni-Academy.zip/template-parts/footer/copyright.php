<?php
/**
 * Copyright Section Template Part
 *
 * @package CBC_School_Modern
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="footer-bottom">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> SchoolName. All rights reserved.</p>
    </div>
</div>
