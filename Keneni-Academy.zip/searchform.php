<?php
/**
 * Search Form Template
 *
 * @package CBC_School_Modern
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

get_template_part('template-parts/forms/search-form');
?>
